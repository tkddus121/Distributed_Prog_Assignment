#ifndef _TIME_H
#define _TIME_H
int timer_get_tod();
int timer_start();
int timer_delay(int interval);
#endif 
